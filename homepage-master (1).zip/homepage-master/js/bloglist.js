function pageopen(){
    window.location.href ="post.html"
}