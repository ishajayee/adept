function openPosts() {
    window.location.href="html/bloglist.html";
}